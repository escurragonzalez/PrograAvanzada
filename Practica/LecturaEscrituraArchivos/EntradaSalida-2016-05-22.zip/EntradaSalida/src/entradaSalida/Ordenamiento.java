package entradaSalida;

public class Ordenamiento {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
